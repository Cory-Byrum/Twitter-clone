import "./styles.css";

function MainContainer() {
  return (
    <div>
      <colgroup className="MainContainer">
        <SideBar />
        <NewsFeedCol />
        <div className="TrendingCol">
          <col />
          <h1>Trending</h1>
        </div>
      </colgroup>
    </div>
  );
}

// function SideBar() {
//  return (
//    <div className="NavBarCol">
//      <col />
//      <input
//        type="image"
//        src="https://i.ibb.co/Z2w9TFf/56206-B94-670-E-4-BE0-9-F86-E09-DDA88-E194.png"
//        alt="logo"
//        name="logo"
//        className="Logo"
//      />
//    </div>
//  );
// }

// function NewsFeedCol() {
//  return (
//    <div className="NewsFeedCol">
//      <col />
//      <h3>News Feed</h3>
//      <p>Placeholder text for newsfeed API bla bla bla</p>
//    </div>
//  );
// }

export default function App() {
  return <div>{MainContainer()}</div>;
}
